<?php
/**
 * FW Gallery Picasa Images Plugin 3.0
 * @copyright (C) 2014 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/
defined( '_JEXEC' ) or die( 'Restricted access' );

?>
<legend><?php echo JText :: _('Picasa images import'); ?></legend>
<?php echo $error_msg; ?>