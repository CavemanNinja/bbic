<?php
/**
 * FW Gallery Facebook Images Plugin 3.0
 * @copyright (C) 2014 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/
defined( '_JEXEC' ) or die( 'Restricted access' );

?>
<legend><?php echo JText :: _('FWGPF_FACEBOOK_IMAGES_IMPORT'); ?></legend>
<?php echo $error_msg; ?>