<?php
/**
 * FW Gallery Facebook Images Plugin 3.0
 * @copyright (C) 2014 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/
defined( '_JEXEC' ) or die( 'Restricted access' );

?>
<legend><?php echo JText :: _('FWGPF_FACEBOOK_IMAGES_IMPORT'); ?></legend>
<?php if ($error_msg) { ?><p><?php echo $error_msg; ?></p><?php } ?>
<a href="<?php echo $link; ?>">
	<img src="http://static.ak.fbcdn.net/rsrc.php/zB6N8/hash/4li2k73z.gif">
</a>
