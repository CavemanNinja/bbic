jQuery(document).ready(function($) {
    // all
    jQuery('#main-menu nav').meanmenu({'meanScreenWidth':'768','meanMenuContainer':'#mean-nav'});
});
