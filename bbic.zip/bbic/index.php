<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Welcome to the BBIC - مرحبا بكم في بي. بي. اي. سي</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Latest compiled and minified CSS -->
<!--    <link rel="stylesheet" href="css/bootstrap.min.css"> -->
	<link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="/bbic/joomla/templates/t3_bs3_blank/css/custom.css"

    <!-- Optional theme -->
<!--    <link rel="stylesheet" href="css/bootstrap-theme.min.css"> -->
    <link rel="stylesheet" href="css/landingpage.css">

    <!-- Latest compiled and minified JavaScript -->
    <script src="js/jquery-1.11.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="css/custom.css">
  </head>
  <body>
    <div class="myjumbotron">
      <div class="landingcard">
      <img src="/bbic/joomla/images/BBICLogoDark.png" class="img-responsive myimage">
      <p>
        <br/>
        <a class="btn btn-primary btn-lg" href="joomla/index.php/en" role="button">English</a>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
        <a class="btn btn-primary btn-lg" href="joomla/index.php/ar" role="button">العربية</a>
      </p>
    </div>
    </div>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>
